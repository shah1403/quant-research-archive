from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


OUT = Path("stock_fi2010_microstructure")
OUT.mkdir(exist_ok=True)
DATA = Path("stock_lob/deeplob_data")


def load_matrix(path, max_events=None):
    arr = np.loadtxt(path, dtype=np.float32)
    if arr.shape[0] == 149:
        arr = arr.T
    if max_events and arr.shape[0] > max_events:
        arr = arr[:max_events]
    return arr


def build_frame():
    parts = []
    for name in [
        "Test_Dst_NoAuction_DecPre_CF_7.txt",
        "Test_Dst_NoAuction_DecPre_CF_8.txt",
        "Test_Dst_NoAuction_DecPre_CF_9.txt",
    ]:
        x = load_matrix(DATA / name)
        lob = x[:, :40].reshape(len(x), 10, 4)
        ask = lob[:, 0, 0]
        aq = lob[:, 0, 1]
        bid = lob[:, 0, 2]
        bq = lob[:, 0, 3]
        mid = (ask + bid) / 2
        spread = ask - bid
        b5 = lob[:, :5, 3].sum(axis=1)
        a5 = lob[:, :5, 1].sum(axis=1)
        imb1 = (bq - aq) / np.maximum(bq + aq, 1e-12)
        imb5 = (b5 - a5) / np.maximum(b5 + a5, 1e-12)
        label10 = x[:, 144]
        parts.append(pd.DataFrame(dict(source=name, ask=ask, bid=bid, aq=aq, bq=bq, mid=mid, spread=spread, imb1=imb1, imb5=imb5, label10=label10)))
    d = pd.concat(parts, ignore_index=True)
    d["i"] = np.arange(len(d))
    return d


def sign_events(d):
    mid = d.mid.to_numpy()
    sp = d.spread.to_numpy()
    src = d.source.to_numpy()
    valid = (sp > 0) & np.isfinite(mid)
    out = []
    anchor = 0
    for j in range(1, len(d)):
        if (not valid[j]) or (not valid[anchor]) or src[j] != src[anchor]:
            anchor = j
            continue
        if abs(mid[j] - mid[anchor]) > sp[anchor] + 1e-12:
            out.append((j, int(mid[j] > mid[anchor])))
            anchor = j
    return np.array([x[0] for x in out], dtype=int), np.array([x[1] for x in out], dtype=int)


def first_passage(d, j, H):
    mid = d.mid.to_numpy()
    sp = d.spread.to_numpy()
    src = d.source.to_numpy()
    k = min(len(d), j + H + 1)
    if k <= j + 1 or src[k - 1] != src[j] or sp[j] <= 0:
        return None, 0, None
    hit = np.flatnonzero(np.abs(mid[j + 1:k] - mid[j]) > sp[j] + 1e-12)
    if len(hit):
        x = j + 1 + int(hit[0])
        return x, 1, int(mid[x] > mid[j])
    return k - 1, 0, None


def run_models(d):
    et, es = sign_events(d)
    rows = []
    n = len(d)
    for H in [10, 50, 100]:
        obs = []
        for j in range(200, n - H, H):
            x, y, up = first_passage(d, j, H)
            if x is None:
                continue
            signs = es[(et <= j) & (et > j - 5000)][-300:]
            prior = (signs.sum() + 1) / (len(signs) + 2)
            last = int(signs[-1]) if len(signs) else -1
            hist_dir = prior
            if len(signs) > 2 and last >= 0:
                nxt = signs[1:][signs[:-1] == last]
                hist_dir = (nxt.sum() + 20 * prior) / (len(nxt) + 20)
            hist = [r for r in obs if r["j"] + H <= j and r["j"] >= j - 5000]
            binid = int(np.clip((float(d.imb1.iloc[j]) + 1) * 5, 0, 9))
            bucket = [r for r in hist if r["bin"] == binid]
            moves = [r for r in bucket if r["y"]]
            imb_dir = (sum(r["up"] for r in moves) + 20 * prior) / (len(moves) + 20)
            both = [r for r in moves if r["last"] == last]
            combined = (sum(r["up"] for r in both) + 20 * hist_dir) / (len(both) + 20)
            base = (sum(r["y"] for r in hist) + 1) / (len(hist) + 2)
            timing = (sum(r["y"] for r in bucket) + 30 * base) / (len(bucket) + 30)
            part = "train" if j < 0.6 * n else ("val" if j < 0.8 * n else "test")
            r = dict(market="FI2010_STOCK_LOB", H=H, j=j, y=y, up=-1 if up is None else up, bin=binid, last=last, p_move=timing, p_rate=prior, p_history=hist_dir, p_imbalance=imb_dir, p_combined=combined, part=part)
            obs.append(r)
            rows.append(r)
    return pd.DataFrame(rows)


def summarize(pred):
    out = []
    selected = []
    for H, g in pred.groupby("H"):
        val = g[g.part == "val"]
        test = g[g.part == "test"].copy()
        if val.empty or test.empty:
            continue
        def f1(th):
            a = val.p_move >= th
            tp = int((a & (val.y == 1)).sum())
            return 2 * tp / max(1, int(a.sum()) + int((val.y == 1).sum()))
        th = max([.1, .2, .3, .4, .5, .6, .7, .8, .9], key=f1)
        test["alert"] = test.p_move >= th
        for model in ["rate", "history", "imbalance", "combined"]:
            move = test.y == 1
            alert = test.alert
            correct = (test["p_" + model] >= .5) == (test.up == 1)
            out.append(dict(H=H, model=model, threshold=th, decisions=len(test), moves=int(move.sum()), alerts=int(alert.sum()), true_alerts=int((alert & move).sum()), false_alerts=int((alert & ~move).sum()), missed=int((~alert & move).sum()), DA_all_moves=float((correct & move).sum() / max(1, move.sum())), DA_alert_moves=float((correct & alert & move).sum() / max(1, (alert & move).sum())), joint_correct=int((correct & alert & move).sum())))
        selected.append(test)
    return pd.DataFrame(out), pd.concat(selected, ignore_index=True)


def make_plot(d, selected):
    q = selected[selected.H == 10].copy()
    if q.empty:
        return
    start = int(q.j.min())
    end = min(len(d), int(q.j.max()) + 10)
    dd = d.iloc[start:end]
    fig, axes = plt.subplots(2, 1, figsize=(14, 7), layout="constrained", sharex=True)
    axes[0].plot(dd.i - start, dd.mid, color="#30394b", lw=.9)
    qq = q[q.alert].copy()
    colors = np.where(((qq.p_combined >= .5) == (qq.up == 1)) & (qq.y == 1), "#128558", np.where(qq.y == 1, "#db8428", "#cc354b"))
    axes[0].scatter(qq.j - start, d.mid.iloc[qq.j].to_numpy(), c=colors, s=18, zorder=3)
    axes[0].set_title("FI-2010 stock LOB: 10-event movement alerts")
    axes[0].set_ylabel("normalized midpoint")
    axes[0].grid(alpha=.15)
    # One-share cross-spread proxy: buy/sell current side, exit at first passage/horizon.
    cash = [0.0]
    xs = []
    for _, r in qq.sort_values("j").iterrows():
        side = 1 if r.p_combined >= .5 else -1
        x, y, up = first_passage(d, int(r.j), 10)
        if x is None:
            continue
        entry = d.ask.iloc[int(r.j)] if side == 1 else d.bid.iloc[int(r.j)]
        exitp = d.bid.iloc[x] if side == 1 else d.ask.iloc[x]
        cash.append(cash[-1] + side * (exitp - entry))
        xs.append(int(r.j) - start)
    if xs:
        axes[1].plot(xs, cash[1:], color="#30394b", lw=1.2)
    axes[1].axhline(0, color="#777", alpha=.5)
    axes[1].set_title("One-share cross-spread gross proxy")
    axes[1].set_xlabel("Events into test segment")
    axes[1].set_ylabel("cum gross")
    axes[1].grid(alpha=.15)
    fig.savefig(OUT / "fi2010_stock_lob_10event.png", dpi=160)
    plt.close(fig)


def main():
    d = build_frame()
    pred = run_models(d)
    metrics, selected = summarize(pred)
    et, _ = sign_events(d)
    audit = pd.DataFrame([dict(rows=len(d), sources=d.source.nunique(), spread_positive=int((d.spread > 0).sum()), mid_min=float(d.mid.min()), mid_max=float(d.mid.max()), spread_median=float(d.spread.median()), realized_moves=len(et), moves_per_1000_events=float(1000 * len(et) / len(d)))])
    audit.to_csv(OUT / "audit.csv", index=False)
    pred.to_csv(OUT / "predictions.csv", index=False)
    selected.to_csv(OUT / "selected_test.csv", index=False)
    metrics.to_csv(OUT / "metrics.csv", index=False)
    make_plot(d, selected)
    print("AUDIT")
    print(audit.to_string(index=False))
    print("\nMETRICS")
    print(metrics.to_string(index=False))


if __name__ == "__main__":
    main()
