from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


OUT = Path("binance_btc_microstructure")
OUT.mkdir(exist_ok=True)
BASE = Path("external_crypto/crypto-microstructure-main/sample_data")


def build_features(kind):
    lob = pd.read_parquet(BASE / f"lobdeep_btc_{kind}_2026-02-16_04.parquet").sort_values("ts_ms").reset_index(drop=True)
    tr = pd.read_parquet(BASE / f"trades_btc_{kind}_2026-02-16_04.parquet").sort_values("ts_ms")
    t = lob.ts_ms.to_numpy() / 1000
    bid = lob.best_bid.to_numpy(float)
    ask = lob.best_ask.to_numpy(float)
    mid = (bid + ask) / 2
    spread = ask - bid
    bq1 = np.array([float(x[0]) if len(x) else np.nan for x in lob.bids_qty])
    aq1 = np.array([float(x[0]) if len(x) else np.nan for x in lob.asks_qty])
    bq5 = np.array([float(np.sum(x[:5])) if len(x) else np.nan for x in lob.bids_qty])
    aq5 = np.array([float(np.sum(x[:5])) if len(x) else np.nan for x in lob.asks_qty])
    imb1 = (bq1 - aq1) / np.maximum(bq1 + aq1, 1e-12)
    imb5 = (bq5 - aq5) / np.maximum(bq5 + aq5, 1e-12)

    tr_t = tr.ts_ms.to_numpy() / 1000
    tr_sign = np.where(tr.side.astype(str).str.lower().to_numpy() == "buy", 1, -1)
    tr_qty = tr.qty.to_numpy(float)
    flow = []
    for now in t:
        lo = np.searchsorted(tr_t, now - 1, side="left")
        hi = np.searchsorted(tr_t, now, side="right")
        den = tr_qty[lo:hi].sum()
        flow.append(0.0 if den <= 0 else float((tr_sign[lo:hi] * tr_qty[lo:hi]).sum() / den))

    return pd.DataFrame(dict(market=f"BINANCE_BTC_{kind.upper()}", t=t, bid=bid, ask=ask, mid=mid, spread=spread, imb1=imb1, imb5=imb5, flow1=np.array(flow)))


def events(d):
    t = d.t.to_numpy(); m = d.mid.to_numpy(); s = d.spread.to_numpy()
    out = []; anchor = 0
    for j in range(1, len(d)):
        if abs(m[j] - m[anchor]) > s[anchor] + 1e-12:
            out.append((t[j], int(m[j] > m[anchor])))
            anchor = j
    return np.array([x[0] for x in out]), np.array([x[1] for x in out])


def first_passage(d, j, H):
    t = d.t.to_numpy(); m = d.mid.to_numpy(); s = d.spread.to_numpy()
    k = np.searchsorted(t, t[j] + H, side="right")
    if k <= j + 1:
        return None, 0, None
    hit = np.flatnonzero(np.abs(m[j + 1:k] - m[j]) > s[j] + 1e-12)
    if len(hit):
        x = j + 1 + int(hit[0])
        return x, 1, int(m[x] > m[j])
    return k - 1, 0, None


def model(d):
    et, es = events(d)
    rows = []
    t = d.t.to_numpy()
    for H in [1, 5, 30]:
        grid = np.arange(np.ceil(t[0] + 30), t[-1] - H, H)
        obs = []
        for now in grid:
            j = np.searchsorted(t, now, side="right") - 1
            x, y, up = first_passage(d, j, H)
            if x is None:
                continue
            signs = es[(et <= now) & (et > now - 300)][-200:]
            prior = (signs.sum() + 1) / (len(signs) + 2)
            last = int(signs[-1]) if len(signs) else -1
            hist_dir = prior
            if len(signs) > 2 and last >= 0:
                nxt = signs[1:][signs[:-1] == last]
                hist_dir = (nxt.sum() + 10 * prior) / (len(nxt) + 10)
            hist = [r for r in obs if r["t"] + H <= now and r["t"] >= now - 300]
            binid = int(np.clip((float(d.imb1.iloc[j]) + 1) * 5, 0, 9))
            flowbin = int(np.clip((float(d.flow1.iloc[j]) + 1) * 2.5, 0, 4))
            bucket = [r for r in hist if r["bin"] == binid]
            moves = [r for r in bucket if r["y"]]
            imb_dir = (sum(r["up"] for r in moves) + 10 * prior) / (len(moves) + 10)
            both = [r for r in moves if r["last"] == last and r["flowbin"] == flowbin]
            combined = (sum(r["up"] for r in both) + 10 * hist_dir) / (len(both) + 10)
            base = (sum(r["y"] for r in hist) + 1) / (len(hist) + 2)
            timing = (sum(r["y"] for r in bucket) + 20 * base) / (len(bucket) + 20)
            part = "train" if now < t[0] + 0.6 * (t[-1] - t[0]) else ("val" if now < t[0] + 0.8 * (t[-1] - t[0]) else "test")
            r = dict(market=d.market.iloc[0], H=H, t=now, j=j, y=y, up=-1 if up is None else up, bin=binid, flowbin=flowbin, last=last, p_move=timing, p_rate=prior, p_history=hist_dir, p_imbalance=imb_dir, p_combined=combined, part=part)
            obs.append(r); rows.append(r)
    return pd.DataFrame(rows)


def summarize(all_d, pred):
    metrics=[]; trades=[]
    for (market,H),g in pred.groupby(["market","H"]):
        val=g[g.part=="val"]; test=g[g.part=="test"].copy()
        if val.empty or test.empty: continue
        def f1(th):
            a=val.p_move>=th; tp=int((a&(val.y==1)).sum())
            return 2*tp/max(1,int(a.sum())+int((val.y==1).sum()))
        th=max([.1,.2,.3,.4,.5,.6,.7,.8,.9],key=f1)
        test["alert"]=test.p_move>=th
        for mod in ["rate","history","imbalance","combined"]:
            move=test.y==1; alert=test.alert; correct=(test["p_"+mod]>=.5)==(test.up==1)
            metrics.append(dict(market=market,H=H,model=mod,threshold=th,decisions=len(test),moves=int(move.sum()),alerts=int(alert.sum()),true_alerts=int((alert&move).sum()),false_alerts=int((alert&~move).sum()),DA_all_moves=float((correct&move).sum()/max(1,move.sum())),DA_alert_moves=float((correct&alert&move).sum()/max(1,(alert&move).sum())),joint_correct=int((correct&alert&move).sum())))
        d=all_d[market]
        cash=5.0
        for _,r in test[test.alert].sort_values("t").iterrows():
            side=1 if r.p_combined>=.5 else -1
            entry_row=d.iloc[int(r.j)]
            entry=float(entry_row.ask if side==1 else entry_row.bid)
            x,moved,actual=first_passage(d,int(r.j),H)
            if x is None: continue
            exit_row=d.iloc[x]
            exitp=float(exit_row.bid if side==1 else exit_row.ask)
            btc_qty=cash/entry
            net=btc_qty*(exitp-entry)*side
            cash+=net
            trades.append(dict(market=market,H=H,t=float(r.t),side="LONG" if side==1 else "SHORT",net=net,cash_after=cash,moved=bool(moved),direction_correct=bool(moved and ((actual==1)==(side==1)))))
    return pd.DataFrame(metrics),pd.DataFrame(trades)


def main():
    data={}
    preds=[]
    audit=[]
    for kind in ["spot","fut"]:
        d=build_features(kind)
        data[d.market.iloc[0]]=d
        et,es=events(d)
        audit.append(dict(market=d.market.iloc[0],rows=len(d),minutes=(d.t.iloc[-1]-d.t.iloc[0])/60,mid_min=d.mid.min(),mid_max=d.mid.max(),spread_median=d.spread.median(),moves=len(et),moves_per_min=len(et)/((d.t.iloc[-1]-d.t.iloc[0])/60)))
        preds.append(model(d))
    pred=pd.concat(preds,ignore_index=True)
    metrics,trades=summarize(data,pred)
    pd.DataFrame(audit).to_csv(OUT/"audit.csv",index=False)
    pred.to_csv(OUT/"predictions.csv",index=False)
    metrics.to_csv(OUT/"metrics.csv",index=False)
    trades.to_csv(OUT/"trades.csv",index=False)
    pnl=[]
    for (m,H),g in trades.groupby(["market","H"]):
        pnl.append(dict(market=m,H=H,trades=len(g),false_timing=int((~g.moved).sum()),moved=int(g.moved.sum()),direction_correct=int(g.direction_correct.sum()),net=float(g.net.sum()),ending_cash=float(g.cash_after.iloc[-1])))
    pd.DataFrame(pnl).to_csv(OUT/"pnl_summary.csv",index=False)
    print("AUDIT"); print(pd.DataFrame(audit).to_string(index=False))
    print("\\nMETRICS"); print(metrics.to_string(index=False))
    print("\\nPNL"); print(pd.DataFrame(pnl).to_string(index=False))
    # Plot most useful test: futures 1s.
    g=trades[(trades.market=="BINANCE_BTC_FUT")&(trades.H==1)]
    d=data["BINANCE_BTC_FUT"]; p=pred[(pred.market=="BINANCE_BTC_FUT")&(pred.H==1)&(pred.part=="test")]
    if not g.empty and not p.empty:
        start=p.t.min(); end=p.t.max()+1; dd=d[(d.t>=start)&(d.t<=end)]
        fig,ax=plt.subplots(figsize=(14,5),layout="constrained")
        ax.plot((dd.t-start)/60,dd.mid,color="#30394b",lw=1,label="mid")
        colors=np.where(g.direction_correct,"#128558",np.where(g.moved,"#db8428","#cc354b"))
        ax2=ax.twinx(); ax2.plot((g.t-g.t.min())/60,g.cash_after,color="#111",lw=1.2,alpha=.8,label="cash")
        ax.scatter((g.t-start)/60,d.iloc[np.searchsorted(d.t,g.t,side="right")-1].mid,c=colors,s=24,zorder=3)
        ax.set_title("Binance BTC futures sample: 1s alerts and $5 executable gross cash")
        ax.set_xlabel("Minutes into test segment"); ax.set_ylabel("BTCUSDT mid"); ax2.set_ylabel("Cash ($)")
        ax.grid(alpha=.15)
        fig.savefig(OUT/"binance_btc_fut_1s.png",dpi=160)

if __name__=="__main__":
    main()
