from pathlib import Path
import math

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


OUT = Path("volatile_microstructure")
OUT.mkdir(exist_ok=True)


MARKETS = {
    "BTC15M": "quant_results/kalshi-btc15m-2026-09-11.txt.zst.features.csv.gz",
    "NFL": "sports_v4/NFL/features.csv.gz",
    "MLB": "sports_v4/MLB/features.csv.gz",
}


def fee(price, q):
    return math.ceil(100 * 0.07 * q * price * (1 - price) - 1e-10) / 100


def max_contracts(price, cash):
    best = 0
    for q in range(1, 1000):
        if q * price + fee(price, q) <= cash + 1e-12:
            best = q
        else:
            break
    return best


def prices(row, side):
    if side == "YES":
        return float(row.ask), float(row.bid)
    return 1 - float(row.bid), 1 - float(row.ask)


def first_passage(d, j, H):
    t = d.t.to_numpy()
    m = d.mid.to_numpy()
    s = d.spread.to_numpy()
    seg = d.segment.to_numpy()
    k = np.searchsorted(t, t[j] + H, side="right")
    if k <= j + 1:
        return None, 0, None
    if not ((s[j:k] > 0).all() and (seg[j:k] == seg[j]).all()):
        return None, 0, None
    hit = np.flatnonzero(np.abs(m[j + 1 : k] - m[j]) > s[j] + 1e-9)
    if len(hit):
        x = j + 1 + int(hit[0])
        return x, 1, int(m[x] > m[j])
    return k - 1, 0, None


def realized_sign_events(d):
    t = d.t.to_numpy()
    m = d.mid.to_numpy()
    s = d.spread.to_numpy()
    seg = d.segment.to_numpy()
    valid = (s > 0) & (d.bid.to_numpy() > 0) & (d.ask.to_numpy() < 1) & np.isfinite(m)
    events = []
    anchor = 0
    for j in range(1, len(d)):
        if not valid[j] or not valid[anchor] or seg[j] != seg[anchor]:
            anchor = j
            continue
        if abs(m[j] - m[anchor]) > s[anchor] + 1e-9:
            events.append((t[j], int(m[j] > m[anchor])))
            anchor = j
    return np.array([x[0] for x in events]), np.array([x[1] for x in events])


def fit_predict_market(name, path):
    d = pd.read_csv(path).sort_values("t").reset_index(drop=True)
    t = d.t.to_numpy()
    m = d.mid.to_numpy()
    s = d.spread.to_numpy()
    valid = (s > 0) & (d.bid.to_numpy() > 0) & (d.ask.to_numpy() < 1) & np.isfinite(m)
    et, es = realized_sign_events(d)
    rows = []
    audit = dict(
        market=name,
        rows=len(d),
        valid=int(valid.sum()),
        minutes=float((t[-1] - t[0]) / 60),
        mid_min=float(np.nanmin(m)),
        mid_max=float(np.nanmax(m)),
        spread_median=float(np.nanmedian(s[valid])),
        spread_p90=float(np.nanquantile(s[valid], 0.9)),
        realized_moves=len(et),
        moves_per_min=float(len(et) / ((t[-1] - t[0]) / 60)),
    )
    for H in [1, 5, 30]:
        if t[-1] - t[0] < H + 90:
            continue
        grid = np.arange(np.ceil(t[0] + 60), t[-1] - H, H)
        obs = []
        for now in grid:
            j = np.searchsorted(t, now, side="right") - 1
            if j < 0 or not valid[j]:
                continue
            x, y, up = first_passage(d, j, H)
            if x is None:
                continue
            signs = es[(et <= now) & (et > now - 1800)][-200:]
            prior = (signs.sum() + 1) / (len(signs) + 2)
            last = int(signs[-1]) if len(signs) else -1
            hist_dir = prior
            if len(signs) > 2 and last >= 0:
                nxt = signs[1:][signs[:-1] == last]
                hist_dir = (nxt.sum() + 10 * prior) / (len(nxt) + 10)
            hist = [r for r in obs if r["t"] + H <= now and r["t"] >= now - 1800]
            imb = float(d.imb1.iloc[j])
            binid = int(np.clip((imb + 1) * 5, 0, 9))
            bucket = [r for r in hist if r["bin"] == binid]
            moves = [r for r in bucket if r["y"]]
            imb_dir = (sum(r["up"] for r in moves) + 10 * prior) / (len(moves) + 10)
            both = [r for r in moves if r["last"] == last]
            combined = (sum(r["up"] for r in both) + 10 * hist_dir) / (len(both) + 10)
            base = (sum(r["y"] for r in hist) + 1) / (len(hist) + 2)
            timing = (sum(r["y"] for r in bucket) + 20 * base) / (len(bucket) + 20)
            part = "train" if now < t[0] + 0.6 * (t[-1] - t[0]) else ("val" if now < t[0] + 0.8 * (t[-1] - t[0]) else "test")
            r = dict(market=name, H=H, t=now, j=j, mid=m[j], spread=s[j], bin=binid, last=last, y=y, up=-1 if up is None else up, p_move=timing, p_base=base, p_rate=prior, p_history=hist_dir, p_imbalance=imb_dir, p_combined=combined, part=part)
            obs.append(r)
        rows.extend(obs)
    return d, audit, pd.DataFrame(rows)


def summarize_and_trade(data, preds):
    metrics = []
    trades = []
    for (market, H), g in preds.groupby(["market", "H"]):
        val = g[g.part == "val"]
        test = g[g.part == "test"].copy()
        if val.empty or test.empty:
            continue

        def f1(th):
            a = val.p_move >= th
            tp = int((a & (val.y == 1)).sum())
            return 2 * tp / max(1, int(a.sum()) + int((val.y == 1).sum()))

        threshold = max([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9], key=f1)
        test["alert"] = test.p_move >= threshold
        for model in ["rate", "history", "imbalance", "combined"]:
            move = test.y == 1
            alert = test.alert
            correct = (test["p_" + model] >= 0.5) == (test.up == 1)
            metrics.append(dict(
                market=market,
                H=H,
                model=model,
                threshold=threshold,
                decisions=len(test),
                moves=int(move.sum()),
                alerts=int(alert.sum()),
                true_alerts=int((alert & move).sum()),
                false_alerts=int((alert & ~move).sum()),
                missed=int((~alert & move).sum()),
                DA_all_moves=float((correct & move).sum() / max(1, move.sum())),
                DA_alert_moves=float((correct & alert & move).sum() / max(1, (alert & move).sum())),
                joint_correct=int((correct & alert & move).sum()),
            ))

        d = data[market]
        cash = 5.0
        for _, r in test[test.alert].sort_values("t").iterrows():
            side = "YES" if r.p_combined >= 0.5 else "NO"
            entry_row = d.iloc[int(r.j)]
            entry, _ = prices(entry_row, side)
            q = max_contracts(entry, cash)
            if q <= 0:
                continue
            x, moved, actual_up = first_passage(d, int(r.j), H)
            if x is None:
                continue
            _, exit_price = prices(d.iloc[x], side)
            net = q * (exit_price - entry) - fee(entry, q) - fee(exit_price, q)
            before = cash
            cash += net
            trades.append(dict(
                market=market,
                H=H,
                t=float(r.t),
                side=side,
                q=q,
                entry=entry,
                exit=exit_price,
                net=net,
                cash_before=before,
                cash_after=cash,
                moved=bool(moved),
                actual_up=None if actual_up is None else bool(actual_up),
                direction_correct=bool(moved and ((actual_up == 1) == (r.p_combined >= 0.5))),
            ))
    return pd.DataFrame(metrics), pd.DataFrame(trades)


def make_plot(data, preds, trades):
    btc = preds[(preds.market == "BTC15M") & (preds.H == 1) & (preds.part == "test")].copy()
    if btc.empty:
        return
    d = data["BTC15M"]
    start = btc.t.min()
    end = btc.t.max() + 1
    dd = d[(d.t >= start) & (d.t <= end)]
    tr = trades[(trades.market == "BTC15M") & (trades.H == 1)].copy()
    fig, axes = plt.subplots(2, 1, figsize=(14, 7), layout="constrained", sharex=True)
    axes[0].plot((dd.t - start) / 60, dd.mid * 100, color="#30394b", lw=1)
    if not tr.empty:
        colors = np.where(tr.direction_correct, "#128558", np.where(tr.moved, "#db8428", "#cc354b"))
        axes[0].scatter((tr.t - start) / 60, data["BTC15M"].iloc[np.searchsorted(data["BTC15M"].t, tr.t, side="right") - 1].mid * 100, c=colors, s=22, zorder=3)
    axes[0].set_title("BTC15M test segment: price and traded timing alerts, 1s horizon")
    axes[0].set_ylabel("YES midpoint (cents)")
    axes[0].grid(alpha=0.15)
    if not tr.empty:
        axes[1].plot((tr.t - tr.t.min()) / 60, tr.cash_after, color="#30394b", lw=1.5)
        axes[1].scatter((tr.t - tr.t.min()) / 60, tr.cash_after, c=colors, s=22)
    axes[1].axhline(5, color="#777", alpha=0.5)
    axes[1].set_title("Strict $5 bankroll")
    axes[1].set_xlabel("Minutes into test segment")
    axes[1].set_ylabel("Cash ($)")
    axes[1].grid(alpha=0.15)
    fig.savefig(OUT / "btc15m_price_bankroll_1s.png", dpi=160)
    plt.close(fig)


def main():
    data = {}
    audits = []
    pred_parts = []
    for name, path in MARKETS.items():
        d, audit, pred = fit_predict_market(name, path)
        data[name] = d
        audits.append(audit)
        pred_parts.append(pred)
    preds = pd.concat(pred_parts, ignore_index=True)
    metrics, trades = summarize_and_trade(data, preds)
    audit = pd.DataFrame(audits).sort_values("moves_per_min", ascending=False)
    audit.to_csv(OUT / "market_audit.csv", index=False)
    preds.to_csv(OUT / "predictions.csv", index=False)
    metrics.to_csv(OUT / "metrics.csv", index=False)
    trades.to_csv(OUT / "strict_5_bankroll_trades.csv", index=False)
    make_plot(data, preds, trades)
    pnl = []
    if not trades.empty:
        for (market, H), g in trades.groupby(["market", "H"]):
            pnl.append(dict(market=market, H=H, trades=len(g), false_timing=int((~g.moved).sum()), moved=int(g.moved.sum()), direction_correct=int(g.direction_correct.sum()), net=float(g.net.sum()), ending_cash=float(g.cash_after.iloc[-1])))
    pd.DataFrame(pnl).to_csv(OUT / "pnl_summary.csv", index=False)
    print("AUDIT")
    print(audit.to_string(index=False))
    print("\nMETRICS")
    print(metrics.to_string(index=False))
    print("\nPNL")
    print(pd.DataFrame(pnl).to_string(index=False))


if __name__ == "__main__":
    main()
